--------------------
ChromePHP
--------------------
Version: 1.0.0
Author: Jan Peca <pecajan@gmail.com>
--------------------

A ChromePHP for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/theboxer/ChromePHP/issues

Install Chrome Logger extension for chrome to start logging
http://craig.is/writing/chrome-logger